EmptySkillObject = {
    "array_type": "NameProperty",
    "id": None,
    "value": {
        "values": []
    },
    "type": "ArrayProperty"
}

EmptyLevelObject = {
    "id": None,
    "value": 1,
    "type": "IntProperty"
}

EmptyRankObject = {
    "id": None,
    "value": 0,
    "type": "IntProperty"
}

EmptyMeleeObject = {
    "id": None,
    "value": 0,
    "type": "IntProperty"
}

EmptyShotObject = {
    "id": None,
    "value": 0,
    "type": "IntProperty"
}

EmptyDefenceObject = {
    "id": None,
    "value": 0,
    "type": "IntProperty"
}

EmptyExpObject = {
    "id": None,
    "value": 0,
    "type": "IntProperty"
}
    
